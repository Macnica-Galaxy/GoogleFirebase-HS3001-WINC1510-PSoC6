/* ========================================
 *
 * Copyright YOUR COMPANY, THE YEAR
 * All Rights Reserved
 * UNPUBLISHED, LICENSED SOFTWARE.
 *
 * CONFIDENTIAL AND PROPRIETARY INFORMATION
 * WHICH IS THE PROPERTY OF your company.
 *
 * ========================================
*/
#include "project.h"
#include "winc1500_api.h"   // primary WINC1500 include file
#include "demo_config.h"    // selects which application to run

#include <stdio.h>

#define HS300X_ADR      0x44

#define HS300X_STALE_DATA           2
#define HS300X_OK                   1
#define HS300X_ERROR_SENSOR_BUSY    0
#define HS300X_ERROR_COLLISION_I2C  0
/*******************************************************************************
* When printf function is called it is redirected to the following functions
* depending on compiler used.
*******************************************************************************/
#if defined (__GNUC__)
/*******************************************************************************
* Function Name: _write
********************************************************************************
* Summary: 
* NewLib C library is used to retarget printf to _write. printf is redirected to 
* this function when GCC compiler is used to print data to terminal using UART. 
*
* \param file
* This variable is not used.
* \param *ptr
* Pointer to the data which will be transfered through UART.
* \param len
* Length of the data to be transfered through UART.
*
* \return
* returns the number of characters transferred using UART.
* \ref int
*******************************************************************************/
   int _write(int file, char *ptr, int len)
    {
        int nChars = 0;

        /* Suppress the compiler warning about an unused variable. */
        if (0 != file)
        {
        }
                
        nChars = Cy_SCB_UART_PutArray(Uart_Printf_HW, ptr, len);
           
        return (nChars);
    }

#elif defined(__ARMCC_VERSION)
    
/*******************************************************************************
* Function Name: fputc
********************************************************************************
* Summary: 
* printf is redirected to this function when MDK compiler is used to print data
* to terminal using UART.
*
* \param ch
* Character to be printed through UART.
*
* \param *file
* pointer to a FILE object that identifies the stream where the character is to be
* written.
*
* \return
* This function returns the character that is written in case of successful
* write operation else in case of error EOF is returned.
* \ref int
*******************************************************************************/
    struct __FILE
    {
        int handle;
    };
    
    enum
    {
        STDIN_HANDLE,
        STDOUT_HANDLE,
        STDERR_HANDLE
    };
    
    FILE __stdin = {STDIN_HANDLE};
    FILE __stdout = {STDOUT_HANDLE};
    FILE __stderr = {STDERR_HANDLE};
    
    int fputc(int ch, FILE *file)
    {
        int ret = EOF;
        switch(file->handle)
        {
            case STDOUT_HANDLE:
                while (0UL == Cy_SCB_UART_Put(Uart_Printf_HW, ch))
                {
                }
                ret = ch;
            break;
                
            case STDERR_HANDLE:
                ret = ch;
            break;
                
            default:
                file = file;
            break;
        }
        return(ret);
    }
    

#endif /* (__GNUC__) */


float HS300xlib_getHumidity(void);
float HS300xlib_getTemperatureC(void);
uint8_t HS300xlib_readSensor(void);
uint8_t HS300xlib_MeasurementReq(void);

float humidity = 0;
float temperature = 0;
float HS300xlib_getHumidity(void){
    return humidity;
}
float HS300xlib_getTemperatureC(void){
    return temperature;
}
uint8_t HS300xlib_readSensor(void){
    uint16_t rawTempMSB;
    uint16_t rawTemp;
    uint16_t rawHumMSB;
    uint16_t rawHum;
    uint8_t  rawStatus;
    cy_en_scb_i2c_status_t errorStatus;
    uint32_t cnt = 0UL;
    cy_en_scb_i2c_command_t cmd = CY_SCB_I2C_ACK;
    uint8_t rawBuff[4];
    errorStatus = Cy_SCB_I2C_MasterSendStart(I2CM_HW, HS300X_ADR, CY_SCB_I2C_READ_XFER, 1000, &I2CM_context);
    if(errorStatus == CY_SCB_I2C_SUCCESS)
    {
        do{
            if (cnt == 3)
            {
                /* The last byte must be NACKed */
                cmd = CY_SCB_I2C_NAK;
            }
            errorStatus = Cy_SCB_I2C_MasterReadByte(I2CM_HW, cmd, &rawBuff[cnt], 1000, &I2CM_context);
            ++cnt;
        }while((errorStatus == CY_SCB_I2C_SUCCESS) && (cnt < 4));
    }

    if ((errorStatus == CY_SCB_I2C_SUCCESS)           ||
    (errorStatus == CY_SCB_I2C_MASTER_MANUAL_NAK) ||
    (errorStatus == CY_SCB_I2C_MASTER_MANUAL_ADDR_NAK))
    {
        /* Send Stop condition on the bus */
        Cy_SCB_I2C_MasterSendStop(I2CM_HW, 1000, &I2CM_context);
    }
    
    rawHumMSB = rawBuff[0] << 8;  // MSB
    rawHum  = rawBuff[1];       // LSB
    rawTempMSB = rawBuff[2] << 8;
    rawTemp= rawBuff[3];

    rawHum |= rawHumMSB;
    rawTemp |= rawTempMSB;
  
    rawStatus = rawTemp >> 14;
    rawHum = rawHum & 0x3FFF; // mask 2 bit first
    rawTemp = rawTemp >>2;     // mask 2 bit last  
    if (rawHum == 0x3FFF) return 0;
    if (rawTemp == 0x3FFF) return 0;
    temperature = (rawTemp* 0.010071415 ) - 40;
    humidity = rawHum * 0.006163516;
    return rawStatus + 1;
}

uint8_t HS300xlib_MeasurementReq(void){
    cy_en_scb_i2c_status_t errorStatus;
    int8_t _status = 0;
    uint8_t iteration = 0;
    errorStatus = Cy_SCB_I2C_MasterSendStart(I2CM_HW, HS300X_ADR, CY_SCB_I2C_WRITE_XFER, 1000, &I2CM_context);
    if(errorStatus == CY_SCB_I2C_SUCCESS)
    {
        errorStatus = Cy_SCB_I2C_MasterSendStop(I2CM_HW, 1000,&I2CM_context);
        if(errorStatus == CY_SCB_I2C_SUCCESS)
        {
            CyDelay(35);
            do {
               _status = HS300xlib_readSensor();     
               iteration ++;
               if (iteration > 100) return HS300X_ERROR_SENSOR_BUSY;   
               CyDelay(1);
            } while (!_status);
            return _status;
        }
        else
            return _status;
    }
    return _status;
}


static volatile uint32_t g_oneMsCounter = 0;  // added after MCC-generated code
uint32_t GetOneMsCounter(void)
{
    uint32_t tmp;
    tmp = g_oneMsCounter;   // get a clean copy of counter variable
    return tmp;
}
static void HandleError(void)
{
     /* Disable all interrupts */
    __disable_irq();

    while(1u) 
    {
        
    }
}
void TimerInterruptHandler(void)
{
    /* Clear the terminal count interrupt */
    ++g_oneMsCounter;
    Cy_TCPWM_ClearInterrupt(Counter_1ms_HW, Counter_1ms_CNT_NUM, CY_TCPWM_INT_ON_TC);
    
}
void Isr_IRQn(void)
{
    /* Clears the triggered pin interrupt */
	Cy_GPIO_ClearInterrupt(IRQn_PORT, IRQn_NUM);
	NVIC_ClearPendingIRQ(SysInt_IRQn_cfg.intrSrc);
    m2m_EintHandler();
}
int main(void)
{
    /* UART initialization status */
    cy_en_scb_uart_status_t uart_status ;
    cy_en_scb_spi_status_t spi_status;
    cy_en_scb_i2c_status_t i2c_status ;
    __enable_irq(); /* Enable global interrupts. */

    /* Initialize UART operation. Config and Context structure is copied from Generated source. */
    uart_status  = Cy_SCB_UART_Init(Uart_Printf_HW, &Uart_Printf_config, &Uart_Printf_context);
    if(uart_status != CY_SCB_UART_SUCCESS)
    {
        HandleError();
    }	
    Cy_SCB_UART_Enable(Uart_Printf_HW);
    Uart_Printf_Start();
    
    i2c_status = Cy_SCB_I2C_Init(I2CM_HW, &I2CM_config, &I2CM_context);
    if(i2c_status != CY_SCB_I2C_SUCCESS)
    {
        HandleError();
    }
    Cy_SCB_I2C_Enable(I2CM_HW);
    
    spi_status = Cy_SCB_SPI_Init(mSPI_HW, &mSPI_config, NULL);
    if(spi_status != CY_SCB_SPI_SUCCESS)
    {
        HandleError();
    }
    Cy_SCB_SPI_Enable(mSPI_HW);
    mSPI_Start();
    
    Cy_SysInt_Init(&isrTimer1ms_cfg, TimerInterruptHandler);
    NVIC_EnableIRQ(isrTimer1ms_cfg.intrSrc); /* Enable the core interrupt */
    Cy_SysInt_Init(&SysInt_IRQn_cfg, Isr_IRQn);
	NVIC_ClearPendingIRQ(SysInt_IRQn_cfg.intrSrc);
	NVIC_EnableIRQ(SysInt_IRQn_cfg.intrSrc);
    
    Counter_1ms_Start();
    
    m2m_wifi_init();
    
    printf("Welcome to ToGoV2 PSoC6 Project...\r\n");
    for(;;)
    {
        if(HS300xlib_MeasurementReq())
        {
            temperature = HS300xlib_getTemperatureC();
            humidity = HS300xlib_getHumidity();
        }
        ApplicationTask();
        m2m_wifi_task();
    }
}
/* [] END OF FILE */
