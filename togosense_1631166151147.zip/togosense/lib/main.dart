import 'package:flutter/material.dart';
import 'package:firebase/firebase.dart' as fb;
import 'package:flutter_spinkit/flutter_spinkit.dart';
import 'package:flutter_svg/flutter_svg.dart';

void main() {
  if (fb.apps.isEmpty) {
    fb.initializeApp(
        apiKey: "",
        authDomain: "",
        databaseURL: "",
        projectId: "",
        storageBucket: "",
        messagingSenderId: "",
        appId: "",
        measurementId: "");
  }
  runApp(ToGoSense());
}

class ToGoSense extends StatefulWidget {
  ToGoSense({Key? key}) : super(key: key);

  @override
  _ToGoSenseState createState() => _ToGoSenseState();
}

class _ToGoSenseState extends State<ToGoSense> {
  var databaseRef = fb.database().ref("sensors");
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
          appBar: AppBar(
            title: Text('ToGoSense'),
            backgroundColor: Color.fromRGBO(133, 1, 132, 1),
          ),
          body: StreamBuilder(
            stream: databaseRef.onValue,
            builder: (BuildContext context, AsyncSnapshot snap) {
              if (!snap.hasError && snap.hasData) {
                fb.DataSnapshot snapshot = snap.data.snapshot;
                List<Widget> items = <Widget>[];
                snapshot.forEach((e) {
                  items.add(Card(
                    color: Colors.grey[200],
                    elevation: 5,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                      crossAxisAlignment: CrossAxisAlignment.stretch,
                      children: [
                        Container(
                          height: 50,
                          padding: EdgeInsets.all(10),
                          // decoration: BoxDecoration(
                          //     border: Border.all(color: Colors.red)),
                          child: FittedBox(
                            child: Text(
                              e.val()['name'].toUpperCase(),
                              style: TextStyle(
                                  letterSpacing: 3,
                                  fontWeight: FontWeight.bold),
                            ),
                          ),
                        ),
                        Expanded(
                            child: Container(
                                padding: EdgeInsets.all(10),
                                // decoration: BoxDecoration(
                                //     border: Border.all(color: Colors.green)),
                                child: FittedBox(
                                    child: Text(
                                  e.val()['value'].toString() +
                                      e.val()['unit'].toString(),
                                  style: TextStyle(
                                      color: Color.fromRGBO(133, 1, 132, 1)),
                                )))),
                        Container(
                          padding: EdgeInsets.all(10),
                          height: 50,
                          // decoration: BoxDecoration(
                          //     border: Border.all(color: Colors.blue)),
                          child: FittedBox(
                            child: Text(
                              DateTime.fromMillisecondsSinceEpoch(
                                      e.val()['timestamp'])
                                  .toString(),
                              style: TextStyle(color: Colors.grey),
                            ),
                          ),
                        ),
                      ],
                    ),
                  ));
                });
                return GridView.extent(
                    maxCrossAxisExtent: 480,
                    padding: EdgeInsets.all(5),
                    children: items);
              } else {
                return SpinKitDoubleBounce(
                    color: Color.fromRGBO(133, 1, 132, 1));
              }
            },
          ),
          bottomNavigationBar: BottomAppBar(
            color: Colors.transparent,
            elevation: 0,
            child: SvgPicture.asset('assets/svg/macnica-galaxy.svg'),
          )),
    );
  }
}
