package com.example.togosense

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
